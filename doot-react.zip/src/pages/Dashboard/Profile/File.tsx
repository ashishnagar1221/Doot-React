import React from "react";

interface FileProps {}
const File = ({}: FileProps) => {
  return <div></div>;
};

export default File;
